# trans19
This is the coding project for HKU Software Engineering course, aiming to construct an online record-keeping system to monitor the virus outspread situation for CHP in Hong Kong.
