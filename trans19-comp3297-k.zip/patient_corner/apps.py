from django.apps import AppConfig


class PatientCornerConfig(AppConfig):
    name = 'patient_corner'
